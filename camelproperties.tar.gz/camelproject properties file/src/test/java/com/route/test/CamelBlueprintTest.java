package com.route.test;

public class CamelBlueprintTest {

}
